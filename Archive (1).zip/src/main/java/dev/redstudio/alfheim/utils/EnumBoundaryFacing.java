package dev.redstudio.alfheim.utils;

public enum EnumBoundaryFacing {
	IN, OUT
}
